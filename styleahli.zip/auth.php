<?php
// Memulai session
session_start();

// Cek apakah form dikirim dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- KREDENSIAL LOGIN (HANYA UNTUK CONTOH) ---
    // Ganti dengan kredensial yang Anda inginkan
    $valid_username = 'admin';
    $valid_password = 'melati040725'; 

    // Ambil data dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validasi kredensial
    if ($username === $valid_username && $password === $valid_password) {
        // Jika benar, set session
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;

        // Alihkan ke halaman dashboard
        header("location: dashboard.php");
    } else {
        // Jika salah, alihkan kembali ke halaman login dengan pesan error
        header("location: login.php?error=1");
    }
} else {
    // Jika bukan metode POST, kembalikan ke login
    header("location: login.php");
}
?>