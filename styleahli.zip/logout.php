<?php
// Memulai session
session_start();

// Hapus semua variabel session
 $_SESSION = array();

// Hancurkan session
session_destroy();

// Alihkan ke halaman utama (index.html)
header("location: index.html");
exit;
?>